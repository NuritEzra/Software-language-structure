#Sara Borgen - 326000841
#Nurit Ezra - 327739637

def twin(num):
    if prime(num)==True:
        if prime(num+2)==True:
            return num+2
        else:
            if prime(num-2)==True:
                return num-2
            else:
                return -1
    else:
        return -1

def prime(n):
    if n < 1:
        return False
    for i in range(2, n-1):
        if n % i == 0:
            return False
    return True


def main():
    print("enter prime number:")
    try:
        num = int(input())
    except ValueError:
        print("invalid input")
        return
    temp=twin(num)
    if temp==-1:
        print("invalid input")
    else:
        print(temp)

if __name__ == "__main__":
    main()